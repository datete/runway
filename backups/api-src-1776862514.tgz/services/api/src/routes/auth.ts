import { Router, Request, Response } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import IORedis from "ioredis";
import { prisma } from "../services/prisma";
import { authMiddleware, JWT_SECRET } from "../middleware/auth";
import { DeviceService } from "../services/device.service";

const router = Router();

// #8: Redis-based rate limiter for login (replaces in-memory Map)
const rateLimitRedis = new IORedis(process.env.REDIS_URL || "redis://localhost:6379", {
  maxRetriesPerRequest: null,
  lazyConnect: true,
});
rateLimitRedis.connect().catch(() => {});

const LOGIN_RATE_LIMIT = 5;
const LOGIN_RATE_WINDOW = 60; // seconds

async function checkLoginRateLimit(ip: string): Promise<boolean> {
  try {
    const key = `ratelimit:login:${ip}`;
    const count = await rateLimitRedis.incr(key);
    if (count === 1) {
      await rateLimitRedis.expire(key, LOGIN_RATE_WINDOW);
    }
    return count <= LOGIN_RATE_LIMIT;
  } catch {
    return true; // Redis error — allow through
  }
}

// POST /api/runway/auth/login
router.post("/login", async (req: Request, res: Response) => {
  const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
  if (!(await checkLoginRateLimit(clientIp))) {
    return res.status(429).json({ error: '登录尝试过于频繁，请稍后再试' });
  }

  const { username, password, device } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: "用户名和密码必填" });
  }

  try {
    const user = await prisma.user.findUnique({ where: { username } });
    if (!user) return res.status(401).json({ error: "用户名或密码错误" });

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: "用户名或密码错误" });

    if (!user.isActive) return res.status(403).json({ error: "账号已被禁用，请联系管理员" });

    const ip = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "";

    // Track device and IP
    let deviceResult;
    try {
      deviceResult = await DeviceService.trackLogin({
        userId: user.id,
        ip,
        userAgent: req.headers["user-agent"],
        device: device ? {
          fingerprint: device.fingerprint,
          deviceName: device.deviceName,
          browser: device.browser,
          os: device.os,
        } : undefined,
      });
    } catch (deviceErr: any) {
      return res.status(403).json({ error: deviceErr.message });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: "24h" }
    );

    await prisma.userLog.create({
      data: {
        userId: user.id,
        action: "login",
        ip,
        detail: deviceResult?.isNewDevice ? "新设备" : undefined,
      },
    }).catch(() => {});

    res.json({
      token,
      user: { id: user.id, username: user.username, role: user.role },
      isNewDevice: deviceResult?.isNewDevice,
      isSuspicious: deviceResult?.isSuspicious,
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/runway/auth/me
router.get("/me", authMiddleware, async (req: Request, res: Response) => {
  res.json(req.user);
});

// GET /api/runway/auth/devices
router.get("/devices", authMiddleware, async (req: Request, res: Response) => {
  try {
    const devices = await DeviceService.getUserDevices(req.user!.id);
    res.json(devices);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/runway/auth/sessions
router.get("/sessions", authMiddleware, async (req: Request, res: Response) => {
  try {
    const sessions = await DeviceService.getUserSessions(req.user!.id);
    res.json(sessions);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/runway/auth/change-password
router.post("/change-password", authMiddleware, async (req: Request, res: Response) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword) {
    return res.status(400).json({ error: "请输入当前密码和新密码" });
  }
  if (newPassword.length < 6) {
    return res.status(400).json({ error: "新密码至少6位" });
  }
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) return res.status(404).json({ error: "用户不存在" });

    const valid = await bcrypt.compare(oldPassword, user.passwordHash);
    if (!valid) return res.status(401).json({ error: "当前密码错误" });

    const hash = await bcrypt.hash(newPassword, 10);
    await prisma.user.update({ where: { id: user.id }, data: { passwordHash: hash } });

    await prisma.userLog.create({
      data: { userId: user.id, action: "change_password", ip: (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() || req.socket.remoteAddress || "" },
    }).catch(() => {});

    res.json({ success: true, message: "密码修改成功" });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// DELETE /api/runway/auth/devices/:id
router.delete("/devices/:id", authMiddleware, async (req: Request, res: Response) => {
  try {
    if (req.user!.role !== 'admin') {
      return res.status(403).json({ error: "只有管理员可以解绑设备，请联系管理员" });
    }
    const deviceId = req.params.id;
    await DeviceService.removeDevice(deviceId);
    res.json({ success: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

export { router as authRouter };
